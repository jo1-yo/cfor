// The extension's hidden page. It holds the microphone and the speaker, because a script on the
// Cloudflare dashboard is not allowed to use the microphone. Takes orders from background.js only.
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type !== 'onramp:offscreen') return;
  const v = self.OnrampVoice;
  if (msg.op === 'listen') { v.listen().then(reply, () => reply({ ok: false, error: 'unsupported' })); return true; }
  if (msg.op === 'stop') v.stop();
  else if (msg.op === 'cancel') v.cancel();
  else if (msg.op === 'say') v.say({ url: msg.url, text: msg.text }, msg.queue);
  else if (msg.op === 'hush') v.hush();
  reply({ ok: true });
});
