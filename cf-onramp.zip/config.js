// Where the Onramp Worker lives. Empty = offline mode (bundled guides only, no live AI steps).
// Local dev: 'http://localhost:8787'. After `wrangler deploy`: your workers.dev URL.
self.ONRAMP_CONFIG = { api: 'https://onramp.janezhang555l.workers.dev' };
