// Toolbar icon: open the picker on the current Cloudflare page, or open the dashboard first.
// Also makes the Onramp server calls, so the page's own network rules never get in the way.
importScripts('config.js');

const SUPPORTED = /^https:\/\/([\w-]+\.)*(cloudflare\.com|cloudflare\.app)\/|^https:\/\/claude\.ai\//;
const FILES = ['data/catalog.js', 'content.js'];

chrome.action.onClicked.addListener(async (tab) => {
  if (tab?.id && SUPPORTED.test(tab.url || '')) {
    try { await chrome.tabs.sendMessage(tab.id, { type: 'onramp:toggle' }); return; } catch {}
    try { // the tab was open before the extension was installed
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: FILES });
      await chrome.tabs.sendMessage(tab.id, { type: 'onramp:toggle' });
      return;
    } catch {}
  }
  await chrome.storage.local.set({ wantPalette: Date.now() });
  chrome.tabs.create({ url: 'https://dash.cloudflare.com/' });
});

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type !== 'onramp:api') return;
  (async () => {
    try {
      const { api } = await chrome.storage.local.get('api');
      const base = (api || self.ONRAMP_CONFIG?.api || '').replace(/\/$/, '');
      if (!base) throw new Error('offline');
      const res = await fetch(base + msg.path, msg.body
        ? { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(msg.body) }
        : undefined);
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Request failed (' + res.status + ')');
      reply({ ok: true, data });
    } catch (e) {
      reply({ ok: false, error: e.message === 'Failed to fetch' ? 'offline' : e.message });
    }
  })();
  return true; // reply comes later
});
