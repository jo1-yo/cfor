// Toolbar icon: open the picker on the current Cloudflare page, or open the dashboard first.
// Also makes the Onramp server calls, so the page's own network rules never get in the way,
// and runs the voice (mic + speaker) through a hidden extension page.
importScripts('config.js');

const SUPPORTED = /^https:\/\/([\w-]+\.)*(cloudflare\.com|cloudflare\.app)\/|^https:\/\/claude\.ai\//;
const FILES = ['data/catalog.js', 'content.js'];

chrome.action.onClicked.addListener(async (tab) => {
  if (tab?.id && SUPPORTED.test(tab.url || '')) {
    try { await chrome.tabs.sendMessage(tab.id, { type: 'onramp:toggle' }); return; } catch {}
    try { // the tab was open before the extension was installed
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: FILES });
      await chrome.tabs.sendMessage(tab.id, { type: 'onramp:toggle' });
      return;
    } catch {}
  }
  await chrome.storage.local.set({ wantPalette: Date.now() });
  chrome.tabs.create({ url: 'https://dash.cloudflare.com/' });
});

// ---------- voice ----------
// The microphone and the speaker live in a hidden extension page (offscreen.html): the Cloudflare dashboard
// forbids the microphone to scripts on the page, and its content rules would block the audio too.
const apiBase = async () => ((await chrome.storage.local.get('api')).api || self.ONRAMP_CONFIG?.api || '').replace(/\/$/, '');
let opening = null;
async function offscreen() {
  if (await chrome.offscreen.hasDocument()) return;
  opening ||= chrome.offscreen.createDocument({
    url: 'offscreen.html', reasons: ['USER_MEDIA', 'AUDIO_PLAYBACK'],
    justification: 'Record a spoken question when the mic button is pressed, and play the spoken answer.',
  }).finally(() => { opening = null; });
  await opening;
}
async function voiceOp(msg) {
  if (msg.op === 'can') return { ok: !!chrome.offscreen };
  if (!chrome.offscreen) return { ok: false, error: 'unsupported' };
  if (msg.op === 'hush' && !(await chrome.offscreen.hasDocument())) return { ok: true };
  await offscreen();
  const out = { type: 'onramp:offscreen', op: msg.op };
  if (msg.op === 'say') {
    const base = await apiBase();
    Object.assign(out, { text: msg.text, queue: !!msg.queue, url: base ? base + '/api/say?t=' + encodeURIComponent(msg.text) : '' });
  }
  const r = await chrome.runtime.sendMessage(out);
  if (msg.op === 'listen' && r?.error === 'permission') {
    // Chrome only shows its microphone prompt on a visible extension page, so open one, once.
    await chrome.windows.create({ url: 'mic.html', type: 'popup', width: 440, height: 360, focused: true });
    return { ok: false, error: 'permission', where: 'window' };
  }
  return r || { ok: false, error: 'unsupported' };
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === 'onramp:voice') {
    voiceOp(msg).then(reply, () => reply({ ok: false, error: 'unsupported' }));
    return true;
  }
  if (msg?.type !== 'onramp:api') return;
  (async () => {
    try {
      const base = await apiBase();
      if (!base) throw new Error('offline');
      const res = await fetch(base + msg.path, msg.body
        ? { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(msg.body) }
        : undefined);
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Request failed (' + res.status + ')');
      reply({ ok: true, data });
    } catch (e) {
      reply({ ok: false, error: e.message === 'Failed to fetch' ? 'offline' : e.message });
    }
  })();
  return true; // reply comes later
});
