// Opened once, the first time the mic is used: Chrome can only show its microphone prompt on a visible extension page.
const t = document.getElementById('t'), d = document.getElementById('d'), go = document.getElementById('go');
async function allow() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((x) => x.stop());
    t.textContent = 'Microphone is on';
    d.textContent = 'Go back to Cloudflare and tap the mic again.';
    go.hidden = true;
    setTimeout(() => window.close(), 1600);
  } catch (e) {
    t.textContent = 'Microphone is blocked';
    d.textContent = e.name === 'NotFoundError' ? 'No microphone was found on this computer.' : 'Click the icon at the left of the address bar, allow the microphone, then press the button again.';
  }
}
go.addEventListener('click', allow);
allow();
